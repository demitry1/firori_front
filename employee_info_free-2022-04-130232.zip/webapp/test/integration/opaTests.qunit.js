/* global QUnit */

sap.ui.require([
	"employeeinfofree/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});