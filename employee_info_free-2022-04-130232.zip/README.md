## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Fri Mar 18 2022 12:01:19 GMT+0900 (대한민국 표준시)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.5.2|
|**Generation Platform**<br>Visual Studio Code|
|**Floorplan Used**<br>1worklist|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://vhcala4hci:50000//sap/opu/odata/sap/ZUI_EMPLOYEE_001
|**Module Name**<br>employee_info_free|
|**Application Title**<br>사원정보관리(freestyle)|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>1.71.19|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Enable Telemetry**<br>True|
|**Object collection**<br>Employee|
|**Object collection key**<br>Pernr|
|**Object ID**<br>Pernr|

## employee_info_free

사원정보관리 freestyle 프로그램

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


